package inter.stmt;

import inter.expr.Expr;
import lexer.Tag;

public class Repeat extends Stmt {
	
	private RepeatStmts stmts;
	private Expr expr;
	
	public Repeat(RepeatStmts rs, Expr e) {
		if ( !e.type().isBool() )
			error("esperada uma "
				+ "expressão lógica");
		stmts = rs;
		expr = e;
		addChild(stmts);
		addChild(expr);
	}
	
	@Override
	public void gen() {//repita STMTS ate (EXPR)
		int l1 = code.newLabel();
		int l2 = code.newLabel();
		int l3 = code.newLabel();
		code.emitBreak(l1);
		code.emitLabel(l1);
		stmts.gen();
		expr.jumping(l2, l3);
		code.emitLabel(l2);
		code.emitBreak(l1);
		code.emitLabel(l3);
		
		
	}
	
	@Override
	public String toString() {
		return Tag.REPEAT.toString();
	}

}
