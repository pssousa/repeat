package inter.stmt;

import inter.Node;

public class RepeatStmts extends Stmt {
	
	public RepeatStmts() {
	}
	
	public void addStmt(Stmt stmt) {
		addChild(stmt);
	}

	@Override
	public void gen() {
		for( Node s: children ) 
			((Stmt)s).gen();
	}

	@Override
	public String toString() {
		return "REPEAT STMTS BLOCK";
	}
}
